
Skoolpedia - Educational Website Project

Skoolpedia is a simple, responsive educational website built using HTML and CSS. It is designed to serve as a learning hub for students, featuring course offerings, contact forms, and essential information about the platform.

## Features
- Home page with hero banner and key highlights
- About page with mission and platform goals
- Courses page featuring different subjects
- Contact page with a form
- Responsive CSS design

## Folder Structure
- index.html
- about.html
- courses.html
- contact.html
- css/style.css

## How to Use
1. Unzip the folder.
2. Open `index.html` in any modern web browser.

You can host it on platforms like GitHub Pages, Netlify, or any static web server.

## License
This project is licensed under the MIT License.
